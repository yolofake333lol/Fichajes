package es.fichajes.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import android.widget.ImageView;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.security.SecureRandom;
import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    // ---- Configuración ----
    private static final String URL_FABRICA = "https://controlpresencia.grupoazvi.com/usuario/datosDiarios.aspx";
    private static final long INACTIVIDAD_MS = 3 * 60 * 1000;   // vuelve a los nombres tras 3 min sin tocar
    private static final long PULSACION_AJUSTES_MS = 2000;      // mantener pulsado el engranaje
    private static final int ANCHO_MIN_BOTON_DP = 300;          // ancho mínimo de cada botón de nombre
    private static final int ALTO_MIN_BOTON_DP = 130;           // alto mínimo de cada botón de nombre
    private static final int MAX_COLUMNAS = 4;
    private static final int ALTO_LOGO_DP = 80;
    private static final int ANCHO_CABECERA_EN_LINEA_DP = 720;  // por debajo, la hora va debajo del logo                 // alto del logo de la cabecera
    private static final int PEDIR_EXPORTAR = 1, PEDIR_IMPORTAR = 2;
    private static final int LETRA_NOMBRE_DP = 40;              // tamaño de letra de los nombres

    // ---- Colores ----
    private static final int AZUL = Color.parseColor("#1F3A5F");
    private static final int FONDO = Color.parseColor("#EEF2F6");
    private static final int TEXTO = Color.parseColor("#14202E");
    private static final int BORDE = Color.parseColor("#C9D3DE");
    private static final int AZUL_LOGO = Color.parseColor("#1A4D8F");
    private static final int GRIS = Color.parseColor("#5B6B7C");
    private static final int ROJO = Color.parseColor("#B3261E");

    private static class Trabajador {
        String nombre, usuario, clave;
        Trabajador(String n, String u, String c) { nombre = n; usuario = u; clave = c; }
    }

    private final List<Trabajador> trabajadores = new ArrayList<>();
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private FrameLayout raiz;
    private LinearLayout pantallaNombres, pantallaWeb, pantallaAjustes, listaAjustes;
    private Rejilla rejilla;
    private ScrollView scrollNombres;
    private LinearLayout cabecera;
    private ImageView logo;
    private boolean relojEnUnaLinea = false;
    private int altoMinBoton = ALTO_MIN_BOTON_DP, letraNombre = LETRA_NOMBRE_DP;
    private TextView reloj, tituloWeb;
    private WebView web;

    private Trabajador enCurso = null;
    private boolean datosEnviados = false;
    private boolean tvrAbierto = false;

    // ======================================================================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("datos", MODE_PRIVATE);
        cargar();

        raiz = new FrameLayout(this);
        raiz.setBackgroundColor(FONDO);
        crearPantallaNombres();
        crearPantallaWeb();
        crearPantallaAjustes();
        setContentView(raiz);

        mostrar(pantallaNombres);
        handler.post(tickReloj);
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void mostrar(View pantalla) {
        pantallaNombres.setVisibility(pantalla == pantallaNombres ? View.VISIBLE : View.GONE);
        pantallaWeb.setVisibility(pantalla == pantallaWeb ? View.VISIBLE : View.GONE);
        pantallaAjustes.setVisibility(pantalla == pantallaAjustes ? View.VISIBLE : View.GONE);
        if (pantalla == pantallaNombres) pintarRejilla();
    }

    // ======================================================================
    // Pantalla de nombres
    // ======================================================================
    private void crearPantallaNombres() {
        pantallaNombres = new LinearLayout(this);
        pantallaNombres.setOrientation(LinearLayout.VERTICAL);

        FrameLayout marcoCabecera = new FrameLayout(this);
        marcoCabecera.setBackgroundColor(Color.WHITE);
        cabecera = new LinearLayout(this);
        marcoCabecera.addView(cabecera, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_asturias);
        logo.setAdjustViewBounds(true);
        cabecera.addView(logo);

        reloj = new TextView(this);
        reloj.setTextColor(AZUL_LOGO);
        reloj.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        cabecera.addView(reloj);
        colocarCabecera();

        marcoCabecera.addView(crearEngranaje(), new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END | Gravity.CENTER_VERTICAL));
        pantallaNombres.addView(marcoCabecera, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        View linea = new View(this);
        linea.setBackgroundColor(AZUL_LOGO);
        pantallaNombres.addView(linea, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4)));

        rejilla = new Rejilla(this);
        rejilla.setPadding(dp(7), dp(7), dp(7), dp(7));
        scrollNombres = new ScrollView(this);
        scrollNombres.setFillViewport(true);
        scrollNombres.setScrollbarFadingEnabled(false);
        scrollNombres.setVerticalScrollBarEnabled(true);
        scrollNombres.addView(rejilla, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        pantallaNombres.addView(scrollNombres, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        raiz.addView(pantallaNombres, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    // Engranaje de ajustes (mantener pulsado 2 s), en la esquina de la cabecera
    private View crearEngranaje() {
        final TextView engranaje = new TextView(this);
        engranaje.setText("⚙");
        engranaje.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        engranaje.setTextColor(GRIS);
        engranaje.setAlpha(0.4f);
        engranaje.setGravity(Gravity.CENTER);
        final Runnable abrir = new Runnable() {
            @Override public void run() { engranaje.setAlpha(0.4f); abrirAjustes(); }
        };
        engranaje.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    engranaje.setAlpha(1f);
                    handler.postDelayed(abrir, PULSACION_AJUSTES_MS);
                } else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) {
                    engranaje.setAlpha(0.4f);
                    handler.removeCallbacks(abrir);
                }
                return true;
            }
        });
        return engranaje;
    }

    private final Runnable tickReloj = new Runnable() {
        @Override public void run() {
            pintarReloj();
            handler.postDelayed(this, 10000);
        }
    };

    private void pintarReloj() {
        Date d = new Date();
        Locale es = new Locale("es", "ES");
        String hora = new SimpleDateFormat("HH:mm", es).format(d);
        String fecha = new SimpleDateFormat("EEEE, d 'de' MMMM", es).format(d);
        if (fecha.length() > 0) fecha = fecha.substring(0, 1).toUpperCase(es) + fecha.substring(1);
        String texto = relojEnUnaLinea ? hora + "   ·   " + fecha : hora + "\n" + fecha;
        android.text.SpannableString sp = new android.text.SpannableString(texto);
        sp.setSpan(new android.text.style.RelativeSizeSpan(relojEnUnaLinea ? 1.15f : 1.5f), 0, hora.length(), 0);
        sp.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), 0, hora.length(), 0);
        reloj.setText(sp);
    }

    // Cabecera según el tamaño de pantalla. La lista de nombres es lo importante:
    // la cabecera se hace más fina cuanto menos alto hay.
    private void colocarCabecera() {
        Configuration c = getResources().getConfiguration();
        int w = c.screenWidthDp, h = c.screenHeightDp;
        boolean enLinea = w >= 560;                 // logo a la izquierda y hora a la derecha
        relojEnUnaLinea = !enLinea || h < 560;      // pantallas bajas: hora y fecha en una línea

        int altoLogo = enLinea ? limitar((int) (h * 0.08f), 36, 64) : limitar((int) (h * 0.07f), 44, 64);
        altoMinBoton = limitar((int) (h * 0.20f), 96, ALTO_MIN_BOTON_DP);
        letraNombre = limitar((int) (altoMinBoton * 0.31f), 28, LETRA_NOMBRE_DP);
        reloj.setTextSize(TypedValue.COMPLEX_UNIT_SP, h < 560 ? 16 : 18);

        if (!enLinea) {
            cabecera.setOrientation(LinearLayout.VERTICAL);
            cabecera.setGravity(Gravity.CENTER_HORIZONTAL);
            cabecera.setPadding(dp(56), dp(10), dp(56), dp(8));
            logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            logo.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(altoLogo)));
            LinearLayout.LayoutParams lpR = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lpR.topMargin = dp(6);
            reloj.setLayoutParams(lpR);
            reloj.setGravity(Gravity.CENTER);
        } else {
            cabecera.setOrientation(LinearLayout.HORIZONTAL);
            cabecera.setGravity(Gravity.CENTER_VERTICAL);
            int v = h < 560 ? dp(6) : dp(10);
            cabecera.setPadding(dp(20), v, dp(56), v);
            logo.setScaleType(ImageView.ScaleType.FIT_START);
            LinearLayout.LayoutParams lpL = new LinearLayout.LayoutParams(0, dp(altoLogo), 1);
            lpL.rightMargin = dp(24);
            logo.setLayoutParams(lpL);
            reloj.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            reloj.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        }
        pintarReloj();
        if (rejilla != null) rejilla.requestLayout();
    }

    private static int limitar(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }

    private void pintarRejilla() {
        rejilla.removeAllViews();
        if (trabajadores.isEmpty()) {
            TextView vacio = new TextView(this);
            vacio.setText("Todavía no hay trabajadores.\n\nMantén pulsado 2 segundos el engranaje ⚙\nde abajo a la derecha para añadirlos.");
            vacio.setTextColor(GRIS);
            vacio.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
            vacio.setGravity(Gravity.CENTER);
            rejilla.addView(vacio);
        } else {
            for (int i = 0; i < trabajadores.size(); i++) rejilla.addView(botonNombre(i));
        }
        rejilla.requestLayout();
        scrollNombres.scrollTo(0, 0);
    }

    /**
     * Rejilla que reparte los botones de nombres ocupando toda la pantalla.
     * Se recalcula sola cada vez que cambia el tamaño (por ejemplo al girar la tablet).
     */
    private class Rejilla extends ViewGroup {
        private int cols = 1, filas = 1, celdaH = 0;

        Rejilla(android.content.Context c) { super(c); }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int w = MeasureSpec.getSize(wSpec);
            int n = getChildCount();
            int ancho = w - getPaddingLeft() - getPaddingRight();
            int m = dp(7);
            if (n == 0 || ancho <= 0) { setMeasuredDimension(w, MeasureSpec.getSize(hSpec)); return; }

            // Columnas según el ancho: botones de al menos ANCHO_MIN_BOTON_DP de ancho
            cols = Math.max(1, Math.min(MAX_COLUMNAS, ancho / dp(ANCHO_MIN_BOTON_DP)));
            cols = Math.min(cols, n);
            filas = (n + cols - 1) / cols;

            // Alto de cada fila: como mínimo ALTO_MIN_BOTON_DP; si sobra pantalla, se estiran
            int altoMin = dp(altoMinBoton);
            celdaH = altoMin;
            if (MeasureSpec.getMode(hSpec) == MeasureSpec.EXACTLY) {
                int alto = MeasureSpec.getSize(hSpec) - getPaddingTop() - getPaddingBottom();
                celdaH = Math.max(altoMin, alto / filas);
            }
            int total = celdaH * filas + getPaddingTop() + getPaddingBottom();

            int cw = Math.max(0, ancho / cols - 2 * m);
            int ch = Math.max(0, celdaH - 2 * m);
            for (int i = 0; i < n; i++) {
                View v = getChildAt(i);
                if ("nombre".equals(v.getTag()) && v instanceof TextView) ajustarLetra((TextView) v, cw);
                v.measure(MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY),
                          MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY));
            }
            setMeasuredDimension(w, total);
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int n = getChildCount();
            if (n == 0) return;
            int ancho = (r - l) - getPaddingLeft() - getPaddingRight();
            int celdaW = ancho / cols;
            int m = dp(7);
            for (int i = 0; i < n; i++) {
                View v = getChildAt(i);
                int x = getPaddingLeft() + (i % cols) * celdaW + m;
                int y = getPaddingTop() + (i / cols) * celdaH + m;
                v.layout(x, y, x + v.getMeasuredWidth(), y + v.getMeasuredHeight());
            }
        }
    }

    // Letra grande fija; solo se reduce si la palabra más larga del nombre no cabe a lo ancho
    private void ajustarLetra(TextView b, int cw) {
        String texto = b.getText().toString();
        int palabra = 4;
        for (String p : texto.split("\\s+")) palabra = Math.max(palabra, p.length());
        float px = dp(letraNombre);
        float porAncho = (cw - dp(24)) / (palabra * 0.62f);
        px = Math.max(dp(20), Math.min(px, porAncho));
        if (Math.abs(b.getTextSize() - px) > 0.5f) b.setTextSize(TypedValue.COMPLEX_UNIT_PX, px);
    }

    private GradientDrawable fondoRedondeado(int color, int borde) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(18));
        g.setStroke(dp(2), borde);
        return g;
    }

    private View botonNombre(int indice) {
        final Trabajador t = trabajadores.get(indice);
        TextView b = new TextView(this);
        b.setText(t.nombre);
        b.setGravity(Gravity.CENTER);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(dp(8), dp(8), dp(8), dp(8));
        StateListDrawable estados = new StateListDrawable();
        estados.addState(new int[]{android.R.attr.state_pressed}, fondoRedondeado(AZUL, AZUL));
        estados.addState(new int[]{}, fondoRedondeado(Color.WHITE, BORDE));
        b.setBackground(estados);
        b.setTextColor(new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_pressed}, new int[]{}},
                new int[]{Color.WHITE, TEXTO}));
        b.setTag("nombre");
        b.setMaxLines(2);
        b.setClickable(true);
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { fichar(t); }
        });
        return b;
    }

    @Override
    public void onConfigurationChanged(Configuration nueva) {
        super.onConfigurationChanged(nueva);
        colocarCabecera();
        if (pantallaNombres.getVisibility() == View.VISIBLE) pintarRejilla();
    }

    // ======================================================================
    // Pantalla web: abre la página de fichajes y rellena usuario y contraseña
    // ======================================================================
    private void crearPantallaWeb() {
        pantallaWeb = new LinearLayout(this);
        pantallaWeb.setOrientation(LinearLayout.VERTICAL);

        LinearLayout barra = new LinearLayout(this);
        barra.setOrientation(LinearLayout.HORIZONTAL);
        barra.setGravity(Gravity.CENTER_VERTICAL);
        barra.setBackgroundColor(AZUL);
        barra.setPadding(dp(12), dp(8), dp(12), dp(8));

        Button terminar = new Button(this);
        terminar.setText("◀  Terminar");
        terminar.setAllCaps(false);
        terminar.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        terminar.setTypeface(Typeface.DEFAULT_BOLD);
        terminar.setTextColor(AZUL);
        GradientDrawable fb = new GradientDrawable();
        fb.setColor(Color.WHITE);
        fb.setCornerRadius(dp(12));
        terminar.setBackground(fb);
        terminar.setPadding(dp(24), dp(10), dp(24), dp(10));
        terminar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { terminar(); }
        });
        barra.addView(terminar);

        tituloWeb = new TextView(this);
        tituloWeb.setTextColor(Color.WHITE);
        tituloWeb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        tituloWeb.setTypeface(Typeface.DEFAULT_BOLD);
        tituloWeb.setGravity(Gravity.END);
        barra.addView(tituloWeb, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        pantallaWeb.addView(barra, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSaveFormData(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        CookieManager.getInstance().setAcceptCookie(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false; // todo se queda dentro de la app
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!datosEnviados) rellenarLogin();
                else if (!tvrAbierto) handler.postDelayed(new Runnable() {
                    @Override public void run() { abrirTVR(8); }
                }, 600);
            }
        });
        pantallaWeb.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        raiz.addView(pantallaWeb, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void fichar(Trabajador t) {
        enCurso = t;
        datosEnviados = false;
        tvrAbierto = false;
        tituloWeb.setText(t.nombre);
        mostrar(pantallaWeb);
        web.loadUrl("about:blank");
        // Empezar siempre de cero: borra la sesión del compañero anterior
        borrarSesion(new Runnable() {
            @Override public void run() {
                web.clearHistory();
                web.loadUrl(prefs.getString("url", URL_FABRICA));
            }
        });
        reiniciarInactividad();
    }

    private void rellenarLogin() {
        if (enCurso == null || datosEnviados) return;
        String js = "(function(){"
                + "var u=document.getElementById('username'),p=document.getElementById('password');"
                + "if(!u||!p)return 'sin-login';"
                + "u.value=" + JSONObject.quote(enCurso.usuario) + ";"
                + "p.value=" + JSONObject.quote(enCurso.clave) + ";"
                + "if(typeof __doPostBack==='function'){__doPostBack('Button_Acceder','');}"
                + "else{var b=document.getElementById('Button_Acceder');if(b)b.click();}"
                + "return 'enviado';})()";
        web.evaluateJavascript(js, new ValueCallback<String>() {
            @Override public void onReceiveValue(String r) {
                if (r != null && r.contains("enviado")) datosEnviados = true;
            }
        });
    }

    // Tras iniciar sesión: abre el menú (tres rayas) y toca la opción "TVR" como lo haría un dedo
    private void abrirTVR(final int intentos) {
        if (enCurso == null || tvrAbierto || intentos <= 0) return;
        String js = "(function(){"
                + "function txt(e){return (e.textContent||'').replace(/\\s+/g,' ').trim().toUpperCase();}"
                + "function vis(e){var r=e.getBoundingClientRect();return r.width>0&&r.height>0;}"
                + "var all=document.querySelectorAll('a,button,li,span,div'),v=null;"
                + "for(var i=all.length-1;i>=0;i--){if(txt(all[i])==='TVR'&&vis(all[i])){v=all[i];break;}}"
                + "if(v){v.scrollIntoView({block:'center'});var r=v.getBoundingClientRect();"
                + "return 'pos:'+(r.left+r.width/2)+','+(r.top+r.height/2)+','+window.innerWidth;}"
                + "if(!window.__menuFichajes){"
                + "var m=document.querySelector('.navbar-toggle,.navbar-toggler,[data-toggle=\\'collapse\\'],[data-bs-toggle=\\'collapse\\']');"
                + "if(m){window.__menuFichajes=true;m.click();return 'menu';}}"
                + "return 'no';})()";
        web.evaluateJavascript(js, new ValueCallback<String>() {
            @Override public void onReceiveValue(String r) {
                String res = r == null ? "" : r.replace("\"", "");
                if (res.startsWith("pos:")) {
                    try {
                        String[] p = res.substring(4).split(",");
                        tocar(Float.parseFloat(p[0]), Float.parseFloat(p[1]), Float.parseFloat(p[2]));
                        tvrAbierto = true;
                        return;
                    } catch (Exception ignorado) { }
                }
                handler.postDelayed(new Runnable() {
                    @Override public void run() { abrirTVR(intentos - 1); }
                }, 700);
            }
        });
    }

    // Simula un toque de dedo real en la web, en coordenadas de la página
    private void tocar(float xCss, float yCss, float anchoCss) {
        if (anchoCss <= 0) return;
        float k = web.getWidth() / anchoCss;
        final float x = xCss * k, y = yCss * k;
        final long t = SystemClock.uptimeMillis();
        MotionEvent abajo = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0);
        web.dispatchTouchEvent(abajo);
        abajo.recycle();
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                long t2 = SystemClock.uptimeMillis();
                MotionEvent arriba = MotionEvent.obtain(t, t2, MotionEvent.ACTION_UP, x, y, 0);
                web.dispatchTouchEvent(arriba);
                arriba.recycle();
            }
        }, 80);
    }

    private void borrarSesion(final Runnable despues) {
        WebStorage.getInstance().deleteAllData();
        final CookieManager cm = CookieManager.getInstance();
        cm.removeAllCookies(new ValueCallback<Boolean>() {
            @Override public void onReceiveValue(Boolean ok) {
                cm.flush();
                if (despues != null) despues.run();
            }
        });
    }

    private void terminar() {
        enCurso = null;
        datosEnviados = false;
        tvrAbierto = false;
        handler.removeCallbacks(porInactividad);
        web.stopLoading();
        web.loadUrl("about:blank");
        borrarSesion(null);
        mostrar(pantallaNombres);
    }

    // Si nadie toca la pantalla en un rato, cierra la sesión y vuelve a los nombres
    private final Runnable porInactividad = new Runnable() {
        @Override public void run() {
            if (pantallaWeb.getVisibility() == View.VISIBLE) terminar();
        }
    };

    private void reiniciarInactividad() {
        handler.removeCallbacks(porInactividad);
        handler.postDelayed(porInactividad, INACTIVIDAD_MS);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (pantallaWeb != null && pantallaWeb.getVisibility() == View.VISIBLE) reiniciarInactividad();
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public void onBackPressed() {
        if (pantallaWeb.getVisibility() == View.VISIBLE) {
            terminar();
        } else if (pantallaAjustes.getVisibility() == View.VISIBLE) {
            mostrar(pantallaNombres);
        } else {
            super.onBackPressed();
        }
    }

    // ======================================================================
    // Ajustes (solo administrador)
    // ======================================================================
    private void crearPantallaAjustes() {
        pantallaAjustes = new LinearLayout(this);
        pantallaAjustes.setOrientation(LinearLayout.VERTICAL);
        pantallaAjustes.setBackgroundColor(FONDO);

        LinearLayout barra = new LinearLayout(this);
        barra.setOrientation(LinearLayout.HORIZONTAL);
        barra.setGravity(Gravity.CENTER_VERTICAL);
        barra.setBackgroundColor(AZUL);
        barra.setPadding(dp(20), dp(10), dp(20), dp(10));
        TextView t = new TextView(this);
        t.setText("Ajustes");
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        barra.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button cerrar = boton("Cerrar", false);
        cerrar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { mostrar(pantallaNombres); }
        });
        barra.addView(cerrar);
        pantallaAjustes.addView(barra);

        ScrollView scroll = new ScrollView(this);
        LinearLayout cuerpo = new LinearLayout(this);
        cuerpo.setOrientation(LinearLayout.VERTICAL);
        cuerpo.setPadding(dp(20), dp(12), dp(20), dp(40));

        cuerpo.addView(subtitulo("Trabajadores"));
        cuerpo.addView(ayuda("Los datos se guardan solo en esta tablet. Usa \"Probar\" para comprobar que cada uno entra bien."));
        listaAjustes = new LinearLayout(this);
        listaAjustes.setOrientation(LinearLayout.VERTICAL);
        cuerpo.addView(listaAjustes);

        Button anadir = boton("+ Añadir trabajador", true);
        anadir.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { editar(-1); }
        });
        LinearLayout.LayoutParams lpA = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpA.topMargin = dp(8);
        cuerpo.addView(anadir, lpA);

        cuerpo.addView(subtitulo("Copiar la lista a otra tablet"));
        cuerpo.addView(ayuda("\"Exportar\" guarda todos los trabajadores en un archivo protegido con una clave que eliges tú. "
                + "Envía ese archivo a la otra tablet (WhatsApp, correo, Bluetooth...) y allí pulsa \"Importar\" y escribe la misma clave."));
        LinearLayout filaCopia = new LinearLayout(this);
        filaCopia.setOrientation(LinearLayout.HORIZONTAL);
        Button exportar = boton("Exportar lista", false);
        exportar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { pedirClaveExportar(); }
        });
        Button importar = boton("Importar lista", false);
        importar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { elegirArchivoImportar(); }
        });
        LinearLayout.LayoutParams lpE = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpE.rightMargin = dp(8);
        filaCopia.addView(exportar, lpE);
        filaCopia.addView(importar);
        cuerpo.addView(filaCopia);

        cuerpo.addView(subtitulo("Página de fichajes"));
        cuerpo.addView(ayuda("Solo cambiar si la empresa cambia la dirección de la web."));
        Button cambiarUrl = boton("Cambiar dirección", false);
        cambiarUrl.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { editarUrl(); }
        });
        cuerpo.addView(cambiarUrl, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        String version = "?";
        try { version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignorado) { }
        cuerpo.addView(subtitulo("Versión de la app"));
        cuerpo.addView(ayuda(version));

        scroll.addView(cuerpo);
        pantallaAjustes.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        raiz.addView(pantallaAjustes, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private TextView subtitulo(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(TEXTO);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(20), 0, dp(4));
        return t;
    }

    private TextView ayuda(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(GRIS);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        t.setPadding(0, 0, 0, dp(10));
        return t;
    }

    private Button boton(String texto, boolean principal) {
        Button b = new Button(this);
        b.setText(texto);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(10));
        if (principal) {
            g.setColor(AZUL);
            b.setTextColor(Color.WHITE);
        } else {
            g.setColor(Color.WHITE);
            g.setStroke(dp(1), BORDE);
            b.setTextColor(TEXTO);
        }
        b.setBackground(g);
        b.setPadding(dp(16), dp(8), dp(16), dp(8));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        return b;
    }

    private void abrirAjustes() {
        pintarListaAjustes();
        mostrar(pantallaAjustes);
    }

    private void pintarListaAjustes() {
        listaAjustes.removeAllViews();
        if (trabajadores.isEmpty()) {
            listaAjustes.addView(ayuda("Aún no hay ninguno."));
        }
        for (int i = 0; i < trabajadores.size(); i++) {
            final int idx = i;
            Trabajador tr = trabajadores.get(i);

            LinearLayout fila = new LinearLayout(this);
            fila.setOrientation(LinearLayout.VERTICAL);
            GradientDrawable g = new GradientDrawable();
            g.setColor(Color.WHITE);
            g.setCornerRadius(dp(12));
            g.setStroke(dp(1), BORDE);
            fila.setBackground(g);
            fila.setPadding(dp(12), dp(10), dp(12), dp(10));

            TextView nombre = new TextView(this);
            nombre.setText(tr.nombre);
            nombre.setTextColor(TEXTO);
            nombre.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
            nombre.setTypeface(Typeface.DEFAULT_BOLD);
            fila.addView(nombre);
            TextView usuario = new TextView(this);
            usuario.setText("Usuario: " + tr.usuario);
            usuario.setTextColor(GRIS);
            usuario.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            fila.addView(usuario);

            LinearLayout botones = new LinearLayout(this);
            botones.setOrientation(LinearLayout.HORIZONTAL);
            botones.setPadding(0, dp(8), 0, 0);

            Button probar = boton("Probar", false);
            probar.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { fichar(trabajadores.get(idx)); }
            });
            Button editarB = boton("Editar", false);
            editarB.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { editar(idx); }
            });
            Button borrar = boton("Borrar", false);
            borrar.setTextColor(ROJO);
            borrar.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { confirmarBorrar(idx); }
            });

            Button[] todos = new Button[]{probar, editarB, borrar};
            for (Button b : todos) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.rightMargin = dp(8);
                botones.addView(b, lp);
            }
            fila.addView(botones);

            LinearLayout.LayoutParams lpF = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lpF.bottomMargin = dp(8);
            listaAjustes.addView(fila, lpF);
        }
    }

    private void confirmarBorrar(final int i) {
        new AlertDialog.Builder(this)
                .setMessage("¿Borrar a " + trabajadores.get(i).nombre + "?")
                .setPositiveButton("Borrar", (d, w) -> {
                    trabajadores.remove(i);
                    guardar();
                    pintarListaAjustes();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private EditText campo(String pista, String valor) {
        EditText e = new EditText(this);
        e.setHint(pista);
        e.setText(valor);
        e.setSingleLine(true);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        return e;
    }

    private TextView etiqueta(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(TEXTO);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(10), 0, 0);
        return t;
    }

    private void editar(final int i) {
        Trabajador tr = i >= 0 ? trabajadores.get(i) : new Trabajador("", "", "");
        LinearLayout caja = new LinearLayout(this);
        caja.setOrientation(LinearLayout.VERTICAL);
        caja.setPadding(dp(20), dp(8), dp(20), 0);

        final EditText nombre = campo("Ej.: Manolo", tr.nombre);
        nombre.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        final EditText usuario = campo("Usuario", tr.usuario);
        usuario.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        final EditText clave = campo("Contraseña", tr.clave);
        clave.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);

        caja.addView(etiqueta("Nombre que se verá en el botón"));
        caja.addView(nombre);
        caja.addView(etiqueta("Usuario de la web de fichajes"));
        caja.addView(usuario);
        caja.addView(etiqueta("Contraseña de la web de fichajes"));
        caja.addView(clave);

        ScrollView sv = new ScrollView(this);
        sv.addView(caja);

        new AlertDialog.Builder(this)
                .setTitle(i >= 0 ? "Editar trabajador" : "Nuevo trabajador")
                .setView(sv)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = nombre.getText().toString().trim();
                    String u = usuario.getText().toString().trim();
                    String c = clave.getText().toString();
                    if (n.isEmpty() || u.isEmpty() || c.isEmpty()) {
                        Toast.makeText(MainActivity.this, "Faltan datos: rellena los tres campos.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    Trabajador nuevo = new Trabajador(n, u, c);
                    if (i >= 0) trabajadores.set(i, nuevo); else trabajadores.add(nuevo);
                    guardar();
                    pintarListaAjustes();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void editarUrl() {
        LinearLayout caja = new LinearLayout(this);
        caja.setOrientation(LinearLayout.VERTICAL);
        caja.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText url = campo("https://...", prefs.getString("url", URL_FABRICA));
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        caja.addView(url);
        new AlertDialog.Builder(this)
                .setTitle("Dirección de la página de fichajes")
                .setView(caja)
                .setPositiveButton("Guardar", (d, w) -> {
                    String v = url.getText().toString().trim();
                    if (!v.isEmpty()) prefs.edit().putString("url", v).apply();
                })
                .setNeutralButton("De fábrica", (d, w) -> prefs.edit().remove("url").apply())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ======================================================================
    // Exportar / importar la lista (archivo cifrado con clave)
    // ======================================================================
    private String claveExportar = null;
    private static final Charset UTF8 = Charset.forName("UTF-8");

    private EditText campoClave() {
        EditText e = campo("Clave (mínimo 4 caracteres)", "");
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        return e;
    }

    private LinearLayout cajaCon(View v) {
        LinearLayout caja = new LinearLayout(this);
        caja.setOrientation(LinearLayout.VERTICAL);
        caja.setPadding(dp(20), dp(8), dp(20), 0);
        caja.addView(v);
        return caja;
    }

    private void pedirClaveExportar() {
        if (trabajadores.isEmpty()) {
            Toast.makeText(this, "No hay trabajadores que exportar.", Toast.LENGTH_LONG).show();
            return;
        }
        final EditText clave = campoClave();
        new AlertDialog.Builder(this)
                .setTitle("Elige una clave para proteger el archivo")
                .setMessage("Apúntala: la necesitarás para importar la lista en la otra tablet.")
                .setView(cajaCon(clave))
                .setPositiveButton("Continuar", (d, w) -> {
                    String c = clave.getText().toString();
                    if (c.length() < 4) {
                        Toast.makeText(MainActivity.this, "La clave debe tener al menos 4 caracteres.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    claveExportar = c;
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/octet-stream");
                    i.putExtra(Intent.EXTRA_TITLE, "lista-fichajes.fichajes");
                    try { startActivityForResult(i, PEDIR_EXPORTAR); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "No se ha podido abrir el selector de archivos.", Toast.LENGTH_LONG).show(); }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void elegirArchivoImportar() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try { startActivityForResult(i, PEDIR_IMPORTAR); }
        catch (Exception e) { Toast.makeText(this, "No se ha podido abrir el selector de archivos.", Toast.LENGTH_LONG).show(); }
    }

    @Override
    protected void onActivityResult(int peticion, int resultado, Intent datos) {
        super.onActivityResult(peticion, resultado, datos);
        if (resultado != RESULT_OK || datos == null || datos.getData() == null) { claveExportar = null; return; }
        Uri uri = datos.getData();
        if (peticion == PEDIR_EXPORTAR && claveExportar != null) {
            try {
                JSONArray a = new JSONArray();
                for (Trabajador t : trabajadores) {
                    JSONObject o = new JSONObject();
                    o.put("nombre", t.nombre); o.put("usuario", t.usuario); o.put("clave", t.clave);
                    a.put(o);
                }
                JSONObject contenido = new JSONObject();
                contenido.put("trabajadores", a);
                contenido.put("url", prefs.getString("url", URL_FABRICA));
                byte[] archivo = cifrar(contenido.toString().getBytes(UTF8), claveExportar);
                OutputStream os = getContentResolver().openOutputStream(uri);
                os.write(archivo);
                os.close();
                Toast.makeText(this, "Lista exportada (" + trabajadores.size() + " trabajadores).", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "No se ha podido guardar el archivo.", Toast.LENGTH_LONG).show();
            }
            claveExportar = null;
        } else if (peticion == PEDIR_IMPORTAR) {
            try {
                InputStream is = getContentResolver().openInputStream(uri);
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
                is.close();
                pedirClaveImportar(bos.toByteArray());
            } catch (Exception e) {
                Toast.makeText(this, "No se ha podido leer el archivo.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void pedirClaveImportar(final byte[] archivo) {
        final EditText clave = campoClave();
        new AlertDialog.Builder(this)
                .setTitle("Escribe la clave del archivo")
                .setView(cajaCon(clave))
                .setPositiveButton("Importar", (d, w) -> {
                    try {
                        JSONObject contenido = new JSONObject(new String(descifrar(archivo, clave.getText().toString()), UTF8));
                        final JSONArray a = contenido.getJSONArray("trabajadores");
                        final String url = contenido.optString("url", "");
                        new AlertDialog.Builder(MainActivity.this)
                                .setMessage("El archivo tiene " + a.length() + " trabajadores. "
                                        + "Se sustituirá la lista actual de esta tablet. ¿Seguir?")
                                .setPositiveButton("Sí, importar", (d2, w2) -> {
                                    try {
                                        trabajadores.clear();
                                        for (int i = 0; i < a.length(); i++) {
                                            JSONObject o = a.getJSONObject(i);
                                            trabajadores.add(new Trabajador(o.optString("nombre"), o.optString("usuario"), o.optString("clave")));
                                        }
                                        if (url.length() > 0 && !url.equals(URL_FABRICA)) prefs.edit().putString("url", url).apply();
                                        guardar();
                                        pintarListaAjustes();
                                        Toast.makeText(MainActivity.this, "Lista importada.", Toast.LENGTH_LONG).show();
                                    } catch (Exception e) {
                                        Toast.makeText(MainActivity.this, "El archivo no es válido.", Toast.LENGTH_LONG).show();
                                    }
                                })
                                .setNegativeButton("Cancelar", null)
                                .show();
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Clave incorrecta o archivo no válido.", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // Formato del archivo: "FICHAJES1" + sal(16) + iv(12) + datos cifrados (AES-GCM), todo en Base64
    private static final String CABECERA_ARCHIVO = "FICHAJES1:";

    private static byte[] derivarClave(String clave, byte[] sal) throws Exception {
        SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        return f.generateSecret(new PBEKeySpec(clave.toCharArray(), sal, 20000, 256)).getEncoded();
    }

    private static byte[] cifrar(byte[] datos, String clave) throws Exception {
        SecureRandom r = new SecureRandom();
        byte[] sal = new byte[16]; r.nextBytes(sal);
        byte[] iv = new byte[12]; r.nextBytes(iv);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(derivarClave(clave, sal), "AES"), new GCMParameterSpec(128, iv));
        byte[] cifrado = c.doFinal(datos);
        byte[] todo = new byte[sal.length + iv.length + cifrado.length];
        System.arraycopy(sal, 0, todo, 0, 16);
        System.arraycopy(iv, 0, todo, 16, 12);
        System.arraycopy(cifrado, 0, todo, 28, cifrado.length);
        return (CABECERA_ARCHIVO + Base64.encodeToString(todo, Base64.NO_WRAP)).getBytes(UTF8);
    }

    private static byte[] descifrar(byte[] archivo, String clave) throws Exception {
        String texto = new String(archivo, UTF8).trim();
        if (!texto.startsWith(CABECERA_ARCHIVO)) throw new Exception("formato");
        byte[] todo = Base64.decode(texto.substring(CABECERA_ARCHIVO.length()), Base64.NO_WRAP);
        byte[] sal = new byte[16], iv = new byte[12];
        System.arraycopy(todo, 0, sal, 0, 16);
        System.arraycopy(todo, 16, iv, 0, 12);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(derivarClave(clave, sal), "AES"), new GCMParameterSpec(128, iv));
        return c.doFinal(todo, 28, todo.length - 28);
    }

    // ======================================================================
    // Guardar y cargar
    // ======================================================================
    private void cargar() {
        trabajadores.clear();
        try {
            JSONArray a = new JSONArray(prefs.getString("trabajadores", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                trabajadores.add(new Trabajador(o.optString("nombre"), o.optString("usuario"), o.optString("clave")));
            }
        } catch (Exception ignorado) {
            // datos vacíos o dañados: empezamos sin trabajadores
        }
        ordenar();
    }

    // Orden alfabético (sin distinguir tildes ni mayúsculas)
    private void ordenar() {
        final Collator col = Collator.getInstance(new Locale("es", "ES"));
        col.setStrength(Collator.PRIMARY);
        Collections.sort(trabajadores, new Comparator<Trabajador>() {
            @Override public int compare(Trabajador a, Trabajador b) { return col.compare(a.nombre, b.nombre); }
        });
    }

    private void guardar() {
        ordenar();
        try {
            JSONArray a = new JSONArray();
            for (Trabajador t : trabajadores) {
                JSONObject o = new JSONObject();
                o.put("nombre", t.nombre);
                o.put("usuario", t.usuario);
                o.put("clave", t.clave);
                a.put(o);
            }
            prefs.edit().putString("trabajadores", a.toString()).apply();
        } catch (Exception e) {
            Toast.makeText(this, "No se ha podido guardar.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
