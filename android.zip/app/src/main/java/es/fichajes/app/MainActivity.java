package es.fichajes.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    // ---- Configuración ----
    private static final String URL_FABRICA = "https://controlpresencia.grupoazvi.com/usuario/datosDiarios.aspx";
    private static final long INACTIVIDAD_MS = 3 * 60 * 1000;   // vuelve a los nombres tras 3 min sin tocar
    private static final long PULSACION_AJUSTES_MS = 2000;      // mantener pulsado el engranaje

    // ---- Colores ----
    private static final int AZUL = Color.parseColor("#1F3A5F");
    private static final int FONDO = Color.parseColor("#EEF2F6");
    private static final int TEXTO = Color.parseColor("#14202E");
    private static final int BORDE = Color.parseColor("#C9D3DE");
    private static final int GRIS = Color.parseColor("#5B6B7C");
    private static final int ROJO = Color.parseColor("#B3261E");

    private static class Trabajador {
        String nombre, usuario, clave;
        Trabajador(String n, String u, String c) { nombre = n; usuario = u; clave = c; }
    }

    private final List<Trabajador> trabajadores = new ArrayList<>();
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private FrameLayout raiz;
    private LinearLayout pantallaNombres, rejilla, pantallaWeb, pantallaAjustes, listaAjustes;
    private TextView reloj, tituloWeb;
    private WebView web;

    private Trabajador enCurso = null;
    private boolean datosEnviados = false;
    private boolean tvrAbierto = false;

    // ======================================================================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("datos", MODE_PRIVATE);
        cargar();

        raiz = new FrameLayout(this);
        raiz.setBackgroundColor(FONDO);
        crearPantallaNombres();
        crearPantallaWeb();
        crearPantallaAjustes();
        setContentView(raiz);

        mostrar(pantallaNombres);
        handler.post(tickReloj);
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void mostrar(View pantalla) {
        pantallaNombres.setVisibility(pantalla == pantallaNombres ? View.VISIBLE : View.GONE);
        pantallaWeb.setVisibility(pantalla == pantallaWeb ? View.VISIBLE : View.GONE);
        pantallaAjustes.setVisibility(pantalla == pantallaAjustes ? View.VISIBLE : View.GONE);
        if (pantalla == pantallaNombres) pintarRejilla();
    }

    // ======================================================================
    // Pantalla de nombres
    // ======================================================================
    private void crearPantallaNombres() {
        pantallaNombres = new LinearLayout(this);
        pantallaNombres.setOrientation(LinearLayout.VERTICAL);

        LinearLayout cabecera = new LinearLayout(this);
        cabecera.setOrientation(LinearLayout.HORIZONTAL);
        cabecera.setGravity(Gravity.CENTER_VERTICAL);
        cabecera.setBackgroundColor(AZUL);
        cabecera.setPadding(dp(20), dp(12), dp(20), dp(12));

        TextView titulo = new TextView(this);
        titulo.setText("Toca tu nombre para fichar");
        titulo.setTextColor(Color.WHITE);
        titulo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        titulo.setTypeface(Typeface.DEFAULT_BOLD);
        cabecera.addView(titulo, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        reloj = new TextView(this);
        reloj.setTextColor(Color.WHITE);
        reloj.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        reloj.setGravity(Gravity.END);
        cabecera.addView(reloj);

        pantallaNombres.addView(cabecera, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        rejilla = new LinearLayout(this);
        rejilla.setOrientation(LinearLayout.VERTICAL);
        rejilla.setPadding(dp(7), dp(7), dp(7), dp(7));
        pantallaNombres.addView(rejilla, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        // Pie con el engranaje (mantener pulsado 2 s)
        LinearLayout pie = new LinearLayout(this);
        pie.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        pie.setPadding(dp(14), 0, dp(14), dp(6));
        final TextView engranaje = new TextView(this);
        engranaje.setText("⚙");
        engranaje.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        engranaje.setTextColor(GRIS);
        engranaje.setAlpha(0.45f);
        engranaje.setGravity(Gravity.CENTER);
        final Runnable abrir = new Runnable() {
            @Override public void run() { engranaje.setAlpha(0.45f); abrirAjustes(); }
        };
        engranaje.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    engranaje.setAlpha(1f);
                    handler.postDelayed(abrir, PULSACION_AJUSTES_MS);
                } else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) {
                    engranaje.setAlpha(0.45f);
                    handler.removeCallbacks(abrir);
                }
                return true;
            }
        });
        pie.addView(engranaje, new LinearLayout.LayoutParams(dp(52), dp(52)));
        pantallaNombres.addView(pie, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        raiz.addView(pantallaNombres, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private final Runnable tickReloj = new Runnable() {
        @Override public void run() {
            Date d = new Date();
            Locale es = new Locale("es", "ES");
            String hora = new SimpleDateFormat("HH:mm", es).format(d);
            String fecha = new SimpleDateFormat("EEEE, d 'de' MMMM", es).format(d);
            if (fecha.length() > 0) fecha = fecha.substring(0, 1).toUpperCase(es) + fecha.substring(1);
            reloj.setText(hora + "\n" + fecha);
            handler.postDelayed(this, 10000);
        }
    };

    private void pintarRejilla() {
        rejilla.post(new Runnable() {
            @Override public void run() { construirRejilla(); }
        });
    }

    private void construirRejilla() {
        rejilla.removeAllViews();
        int ancho = rejilla.getWidth() - rejilla.getPaddingLeft() - rejilla.getPaddingRight();
        int alto = rejilla.getHeight() - rejilla.getPaddingTop() - rejilla.getPaddingBottom();
        if (ancho <= 0 || alto <= 0) { pintarRejilla(); return; }

        int n = trabajadores.size();
        if (n == 0) {
            TextView vacio = new TextView(this);
            vacio.setText("Todavía no hay trabajadores.\n\nMantén pulsado 2 segundos el engranaje ⚙\nde abajo a la derecha para añadirlos.");
            vacio.setTextColor(GRIS);
            vacio.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
            vacio.setGravity(Gravity.CENTER);
            rejilla.addView(vacio, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            return;
        }

        // Elegir columnas para que los botones sean lo más grandes posible
        int cols = 1;
        float mejor = -1;
        for (int c = 1; c <= n; c++) {
            int f = (n + c - 1) / c;
            float punt = Math.min(ancho / (float) c, (alto / (float) f) * 1.8f);
            if (punt > mejor) { mejor = punt; cols = c; }
        }
        int filas = (n + cols - 1) / cols;
        float celdaAlto = alto / (float) filas;
        float celdaAncho = ancho / (float) cols;

        int i = 0;
        for (int f = 0; f < filas; f++) {
            LinearLayout fila = new LinearLayout(this);
            fila.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < cols; c++) {
                View celda = (i < n) ? botonNombre(i, celdaAncho, celdaAlto) : new View(this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1);
                lp.setMargins(dp(7), dp(7), dp(7), dp(7));
                fila.addView(celda, lp);
                i++;
            }
            rejilla.addView(fila, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        }
    }

    private GradientDrawable fondoRedondeado(int color, int borde) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(18));
        g.setStroke(dp(2), borde);
        return g;
    }

    private View botonNombre(int indice, float celdaAncho, float celdaAlto) {
        final Trabajador t = trabajadores.get(indice);
        TextView b = new TextView(this);
        b.setText(t.nombre);
        b.setGravity(Gravity.CENTER);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(dp(8), dp(8), dp(8), dp(8));
        StateListDrawable estados = new StateListDrawable();
        estados.addState(new int[]{android.R.attr.state_pressed}, fondoRedondeado(AZUL, AZUL));
        estados.addState(new int[]{}, fondoRedondeado(Color.WHITE, BORDE));
        b.setBackground(estados);
        b.setTextColor(new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_pressed}, new int[]{}},
                new int[]{Color.WHITE, TEXTO}));
        // Tamaño de letra según el hueco disponible
        int letras = Math.max(4, t.nombre.length());
        float px = Math.min(celdaAlto * 0.30f, (celdaAncho - dp(30)) / (letras * 0.62f));
        px = Math.max(dp(14), Math.min(px, dp(60)));
        b.setTextSize(TypedValue.COMPLEX_UNIT_PX, px);
        b.setClickable(true);
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { fichar(t); }
        });
        return b;
    }

    @Override
    public void onConfigurationChanged(Configuration nueva) {
        super.onConfigurationChanged(nueva);
        if (pantallaNombres.getVisibility() == View.VISIBLE) pintarRejilla();
    }

    // ======================================================================
    // Pantalla web: abre la página de fichajes y rellena usuario y contraseña
    // ======================================================================
    private void crearPantallaWeb() {
        pantallaWeb = new LinearLayout(this);
        pantallaWeb.setOrientation(LinearLayout.VERTICAL);

        LinearLayout barra = new LinearLayout(this);
        barra.setOrientation(LinearLayout.HORIZONTAL);
        barra.setGravity(Gravity.CENTER_VERTICAL);
        barra.setBackgroundColor(AZUL);
        barra.setPadding(dp(12), dp(8), dp(12), dp(8));

        Button terminar = new Button(this);
        terminar.setText("◀  Terminar");
        terminar.setAllCaps(false);
        terminar.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        terminar.setTypeface(Typeface.DEFAULT_BOLD);
        terminar.setTextColor(AZUL);
        GradientDrawable fb = new GradientDrawable();
        fb.setColor(Color.WHITE);
        fb.setCornerRadius(dp(12));
        terminar.setBackground(fb);
        terminar.setPadding(dp(24), dp(10), dp(24), dp(10));
        terminar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { terminar(); }
        });
        barra.addView(terminar);

        tituloWeb = new TextView(this);
        tituloWeb.setTextColor(Color.WHITE);
        tituloWeb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        tituloWeb.setTypeface(Typeface.DEFAULT_BOLD);
        tituloWeb.setGravity(Gravity.END);
        barra.addView(tituloWeb, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        pantallaWeb.addView(barra, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSaveFormData(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        CookieManager.getInstance().setAcceptCookie(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false; // todo se queda dentro de la app
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!datosEnviados) rellenarLogin();
                else if (!tvrAbierto) handler.postDelayed(new Runnable() {
                    @Override public void run() { abrirTVR(8); }
                }, 600);
            }
        });
        pantallaWeb.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        raiz.addView(pantallaWeb, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void fichar(Trabajador t) {
        enCurso = t;
        datosEnviados = false;
        tvrAbierto = false;
        tituloWeb.setText(t.nombre);
        mostrar(pantallaWeb);
        web.loadUrl("about:blank");
        // Empezar siempre de cero: borra la sesión del compañero anterior
        borrarSesion(new Runnable() {
            @Override public void run() {
                web.clearHistory();
                web.loadUrl(prefs.getString("url", URL_FABRICA));
            }
        });
        reiniciarInactividad();
    }

    private void rellenarLogin() {
        if (enCurso == null || datosEnviados) return;
        String js = "(function(){"
                + "var u=document.getElementById('username'),p=document.getElementById('password');"
                + "if(!u||!p)return 'sin-login';"
                + "u.value=" + JSONObject.quote(enCurso.usuario) + ";"
                + "p.value=" + JSONObject.quote(enCurso.clave) + ";"
                + "if(typeof __doPostBack==='function'){__doPostBack('Button_Acceder','');}"
                + "else{var b=document.getElementById('Button_Acceder');if(b)b.click();}"
                + "return 'enviado';})()";
        web.evaluateJavascript(js, new ValueCallback<String>() {
            @Override public void onReceiveValue(String r) {
                if (r != null && r.contains("enviado")) datosEnviados = true;
            }
        });
    }

    // Tras iniciar sesión, pulsa la opción "TVR" del menú (Terminal Virtual con Entrada/Salida)
    private void abrirTVR(final int intentos) {
        if (enCurso == null || tvrAbierto || intentos <= 0) return;
        String js = "(function(){"
                + "function txt(e){return (e.textContent||'').replace(/\\s+/g,' ').trim().toUpperCase();}"
                + "function visible(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length);}"
                + "var tvr=null,as=document.querySelectorAll('a,button');"
                + "for(var i=0;i<as.length;i++){if(txt(as[i])==='TVR'){tvr=as[i];break;}}"
                + "if(!tvr){var os=document.querySelectorAll('li,span,div');"
                + "for(var j=0;j<os.length;j++){if(txt(os[j])==='TVR'){tvr=os[j].querySelector('a,button')||os[j];break;}}}"
                + "if(tvr&&visible(tvr)){tvr.click();return 'ok';}"
                + "if(!window.__menuFichajes){"
                + "var m=document.querySelector('.navbar-toggle,.navbar-toggler,[data-toggle=\\'collapse\\'],[data-bs-toggle=\\'collapse\\']');"
                + "if(m){window.__menuFichajes=true;m.click();return 'menu';}}"
                + "if(tvr){tvr.click();return 'ok';}"
                + "return 'no';})()";
        web.evaluateJavascript(js, new ValueCallback<String>() {
            @Override public void onReceiveValue(String r) {
                if (r != null && r.contains("ok")) {
                    tvrAbierto = true;
                } else {
                    handler.postDelayed(new Runnable() {
                        @Override public void run() { abrirTVR(intentos - 1); }
                    }, 700);
                }
            }
        });
    }

    private void borrarSesion(final Runnable despues) {
        WebStorage.getInstance().deleteAllData();
        final CookieManager cm = CookieManager.getInstance();
        cm.removeAllCookies(new ValueCallback<Boolean>() {
            @Override public void onReceiveValue(Boolean ok) {
                cm.flush();
                if (despues != null) despues.run();
            }
        });
    }

    private void terminar() {
        enCurso = null;
        datosEnviados = false;
        tvrAbierto = false;
        handler.removeCallbacks(porInactividad);
        web.stopLoading();
        web.loadUrl("about:blank");
        borrarSesion(null);
        mostrar(pantallaNombres);
    }

    // Si nadie toca la pantalla en un rato, cierra la sesión y vuelve a los nombres
    private final Runnable porInactividad = new Runnable() {
        @Override public void run() {
            if (pantallaWeb.getVisibility() == View.VISIBLE) terminar();
        }
    };

    private void reiniciarInactividad() {
        handler.removeCallbacks(porInactividad);
        handler.postDelayed(porInactividad, INACTIVIDAD_MS);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (pantallaWeb != null && pantallaWeb.getVisibility() == View.VISIBLE) reiniciarInactividad();
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public void onBackPressed() {
        if (pantallaWeb.getVisibility() == View.VISIBLE) {
            terminar();
        } else if (pantallaAjustes.getVisibility() == View.VISIBLE) {
            mostrar(pantallaNombres);
        } else {
            super.onBackPressed();
        }
    }

    // ======================================================================
    // Ajustes (solo administrador)
    // ======================================================================
    private void crearPantallaAjustes() {
        pantallaAjustes = new LinearLayout(this);
        pantallaAjustes.setOrientation(LinearLayout.VERTICAL);
        pantallaAjustes.setBackgroundColor(FONDO);

        LinearLayout barra = new LinearLayout(this);
        barra.setOrientation(LinearLayout.HORIZONTAL);
        barra.setGravity(Gravity.CENTER_VERTICAL);
        barra.setBackgroundColor(AZUL);
        barra.setPadding(dp(20), dp(10), dp(20), dp(10));
        TextView t = new TextView(this);
        t.setText("Ajustes");
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        barra.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button cerrar = boton("Cerrar", false);
        cerrar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { mostrar(pantallaNombres); }
        });
        barra.addView(cerrar);
        pantallaAjustes.addView(barra);

        ScrollView scroll = new ScrollView(this);
        LinearLayout cuerpo = new LinearLayout(this);
        cuerpo.setOrientation(LinearLayout.VERTICAL);
        cuerpo.setPadding(dp(20), dp(12), dp(20), dp(40));

        cuerpo.addView(subtitulo("Trabajadores"));
        cuerpo.addView(ayuda("Los datos se guardan solo en esta tablet. Usa \"Probar\" para comprobar que cada uno entra bien."));
        listaAjustes = new LinearLayout(this);
        listaAjustes.setOrientation(LinearLayout.VERTICAL);
        cuerpo.addView(listaAjustes);

        Button anadir = boton("+ Añadir trabajador", true);
        anadir.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { editar(-1); }
        });
        LinearLayout.LayoutParams lpA = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpA.topMargin = dp(8);
        cuerpo.addView(anadir, lpA);

        cuerpo.addView(subtitulo("Página de fichajes"));
        cuerpo.addView(ayuda("Solo cambiar si la empresa cambia la dirección de la web."));
        Button cambiarUrl = boton("Cambiar dirección", false);
        cambiarUrl.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { editarUrl(); }
        });
        cuerpo.addView(cambiarUrl, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        String version = "?";
        try { version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignorado) { }
        cuerpo.addView(subtitulo("Versión de la app"));
        cuerpo.addView(ayuda(version));

        scroll.addView(cuerpo);
        pantallaAjustes.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        raiz.addView(pantallaAjustes, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private TextView subtitulo(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(TEXTO);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(20), 0, dp(4));
        return t;
    }

    private TextView ayuda(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(GRIS);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        t.setPadding(0, 0, 0, dp(10));
        return t;
    }

    private Button boton(String texto, boolean principal) {
        Button b = new Button(this);
        b.setText(texto);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(10));
        if (principal) {
            g.setColor(AZUL);
            b.setTextColor(Color.WHITE);
        } else {
            g.setColor(Color.WHITE);
            g.setStroke(dp(1), BORDE);
            b.setTextColor(TEXTO);
        }
        b.setBackground(g);
        b.setPadding(dp(16), dp(8), dp(16), dp(8));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        return b;
    }

    private void abrirAjustes() {
        pintarListaAjustes();
        mostrar(pantallaAjustes);
    }

    private void pintarListaAjustes() {
        listaAjustes.removeAllViews();
        if (trabajadores.isEmpty()) {
            listaAjustes.addView(ayuda("Aún no hay ninguno."));
        }
        for (int i = 0; i < trabajadores.size(); i++) {
            final int idx = i;
            Trabajador tr = trabajadores.get(i);

            LinearLayout fila = new LinearLayout(this);
            fila.setOrientation(LinearLayout.VERTICAL);
            GradientDrawable g = new GradientDrawable();
            g.setColor(Color.WHITE);
            g.setCornerRadius(dp(12));
            g.setStroke(dp(1), BORDE);
            fila.setBackground(g);
            fila.setPadding(dp(12), dp(10), dp(12), dp(10));

            TextView nombre = new TextView(this);
            nombre.setText(tr.nombre);
            nombre.setTextColor(TEXTO);
            nombre.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
            nombre.setTypeface(Typeface.DEFAULT_BOLD);
            fila.addView(nombre);
            TextView usuario = new TextView(this);
            usuario.setText("Usuario: " + tr.usuario);
            usuario.setTextColor(GRIS);
            usuario.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            fila.addView(usuario);

            LinearLayout botones = new LinearLayout(this);
            botones.setOrientation(LinearLayout.HORIZONTAL);
            botones.setPadding(0, dp(8), 0, 0);

            Button subir = boton("▲", false);
            subir.setEnabled(i > 0);
            subir.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { mover(idx, -1); }
            });
            Button bajar = boton("▼", false);
            bajar.setEnabled(i < trabajadores.size() - 1);
            bajar.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { mover(idx, 1); }
            });
            Button probar = boton("Probar", false);
            probar.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { fichar(trabajadores.get(idx)); }
            });
            Button editarB = boton("Editar", false);
            editarB.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { editar(idx); }
            });
            Button borrar = boton("Borrar", false);
            borrar.setTextColor(ROJO);
            borrar.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { confirmarBorrar(idx); }
            });

            Button[] todos = new Button[]{subir, bajar, probar, editarB, borrar};
            for (Button b : todos) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.rightMargin = dp(8);
                botones.addView(b, lp);
            }
            fila.addView(botones);

            LinearLayout.LayoutParams lpF = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lpF.bottomMargin = dp(8);
            listaAjustes.addView(fila, lpF);
        }
    }

    private void mover(int i, int dir) {
        int j = i + dir;
        if (j < 0 || j >= trabajadores.size()) return;
        Trabajador a = trabajadores.get(i);
        trabajadores.set(i, trabajadores.get(j));
        trabajadores.set(j, a);
        guardar();
        pintarListaAjustes();
    }

    private void confirmarBorrar(final int i) {
        new AlertDialog.Builder(this)
                .setMessage("¿Borrar a " + trabajadores.get(i).nombre + "?")
                .setPositiveButton("Borrar", (d, w) -> {
                    trabajadores.remove(i);
                    guardar();
                    pintarListaAjustes();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private EditText campo(String pista, String valor) {
        EditText e = new EditText(this);
        e.setHint(pista);
        e.setText(valor);
        e.setSingleLine(true);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        return e;
    }

    private TextView etiqueta(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(TEXTO);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(10), 0, 0);
        return t;
    }

    private void editar(final int i) {
        Trabajador tr = i >= 0 ? trabajadores.get(i) : new Trabajador("", "", "");
        LinearLayout caja = new LinearLayout(this);
        caja.setOrientation(LinearLayout.VERTICAL);
        caja.setPadding(dp(20), dp(8), dp(20), 0);

        final EditText nombre = campo("Ej.: Manolo", tr.nombre);
        nombre.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        final EditText usuario = campo("Usuario", tr.usuario);
        usuario.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        final EditText clave = campo("Contraseña", tr.clave);
        clave.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);

        caja.addView(etiqueta("Nombre que se verá en el botón"));
        caja.addView(nombre);
        caja.addView(etiqueta("Usuario de la web de fichajes"));
        caja.addView(usuario);
        caja.addView(etiqueta("Contraseña de la web de fichajes"));
        caja.addView(clave);

        ScrollView sv = new ScrollView(this);
        sv.addView(caja);

        new AlertDialog.Builder(this)
                .setTitle(i >= 0 ? "Editar trabajador" : "Nuevo trabajador")
                .setView(sv)
                .setPositiveButton("Guardar", (d, w) -> {
                    String n = nombre.getText().toString().trim();
                    String u = usuario.getText().toString().trim();
                    String c = clave.getText().toString();
                    if (n.isEmpty() || u.isEmpty() || c.isEmpty()) {
                        Toast.makeText(MainActivity.this, "Faltan datos: rellena los tres campos.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    Trabajador nuevo = new Trabajador(n, u, c);
                    if (i >= 0) trabajadores.set(i, nuevo); else trabajadores.add(nuevo);
                    guardar();
                    pintarListaAjustes();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void editarUrl() {
        LinearLayout caja = new LinearLayout(this);
        caja.setOrientation(LinearLayout.VERTICAL);
        caja.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText url = campo("https://...", prefs.getString("url", URL_FABRICA));
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        caja.addView(url);
        new AlertDialog.Builder(this)
                .setTitle("Dirección de la página de fichajes")
                .setView(caja)
                .setPositiveButton("Guardar", (d, w) -> {
                    String v = url.getText().toString().trim();
                    if (!v.isEmpty()) prefs.edit().putString("url", v).apply();
                })
                .setNeutralButton("De fábrica", (d, w) -> prefs.edit().remove("url").apply())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ======================================================================
    // Guardar y cargar
    // ======================================================================
    private void cargar() {
        trabajadores.clear();
        try {
            JSONArray a = new JSONArray(prefs.getString("trabajadores", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                trabajadores.add(new Trabajador(o.optString("nombre"), o.optString("usuario"), o.optString("clave")));
            }
        } catch (Exception ignorado) {
            // datos vacíos o dañados: empezamos sin trabajadores
        }
    }

    private void guardar() {
        try {
            JSONArray a = new JSONArray();
            for (Trabajador t : trabajadores) {
                JSONObject o = new JSONObject();
                o.put("nombre", t.nombre);
                o.put("usuario", t.usuario);
                o.put("clave", t.clave);
                a.put(o);
            }
            prefs.edit().putString("trabajadores", a.toString()).apply();
        } catch (Exception e) {
            Toast.makeText(this, "No se ha podido guardar.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
